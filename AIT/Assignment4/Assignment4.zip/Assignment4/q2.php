<?php
$Fname ="Chhagan";
$Lname = "Kumawat";

echo $Fname.$Lname;

?>