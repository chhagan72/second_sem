<?php
$createdate = date("d-m-Y H:i:s");
echo"Current date  and time is ".$createdate ."<br>";
echo"Current date  and time is ".date("m-d-Y H:i:s")."<br>";
echo"Current date  and time is ".date("Y-m-d H:i:s");

?>