<?php
$car = array(array("Chhagan",100,200),array("Raj",200,200),array("Prathmesh",300,200)
);
echo "The car name: ".$car[0][0];
?>
