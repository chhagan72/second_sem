<?php
$car = array("TATA","NEXON","HUDDAI");
echo "The car name: ".$car[0];
?>