<?php
$car = array("TATA"=>1000,"NEXON"=>2000,"HyUDAI"=>3000);
echo "The car name: ".$car["TATA"]."<br>";
echo "The car name: ".$car["NEXON"]."<br>";
echo "The car name: ".$car["HyUDAI"];
?>