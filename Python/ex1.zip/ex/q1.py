
import numpy as np
a =np.array([[1,2,3,4,5],[6,7,8,9,0]])
print(a)

# Extract odd rows
odd_rows = a[1::2]
print("Odd rows:")
print(odd_rows)

# Extract even columns
even_cols = a[:, ::2]
print("Even columns:")
print(even_cols)