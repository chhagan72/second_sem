import numpy as np

arr = np.array([[1, 2, 3], [4, 5, 6], [7, 8, 9]])
arr = np.delete(arr, 1, axis=1)
print("Delete 2nd column \n",arr)

n =np.array([10,12,13])
m = np.insert(arr,1,n,axis=1)
print("Add the new column \n",m)



