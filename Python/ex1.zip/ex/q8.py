import numpy as np
a = np.zeros((9,9), dtype=int)
a[::2]=1
print(a)