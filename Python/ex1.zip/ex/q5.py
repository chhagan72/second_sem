import numpy as np
arr = np.array([[1, 2, 3],[4, 5, 6]])
print("Max from axis 0:", np.amax(arr, axis=0))
print("Min from axis 1:", np.amin(arr, axis=1))