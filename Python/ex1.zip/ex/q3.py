import numpy as np

a = np.arange(13, 40).reshape(9, 3)
sub_arrs = np.split(a, 3, axis=0)
# print("\n",sub_arrs,"\n")
for i, sub_a in enumerate(sub_arrs):
    print(f"Sub-array {i+1}:")
    print(sub_a)
    print()