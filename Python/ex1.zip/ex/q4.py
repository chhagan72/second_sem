import numpy as np 
a = np.array([[1,5,3,4],[5,2,7,8],[9,1,11,12]])
# print(a)
a1 = a[:,a[1, :].argsort()]
print("Row wise sorted \n",a1)

a2 = a[a[:, 1].argsort()]
print("Column wise sorted \n",a2)