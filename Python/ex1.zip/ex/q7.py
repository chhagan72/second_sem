import numpy as np
a = np.ones(5)*10
b = np.ones(5)
print(a)
print(b)
print(a+b)