my_list = ["Apple", "Banana", "Cherry", "Date", "Fig"]
for item in my_list:
    print(item)