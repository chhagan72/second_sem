my_list = [4, 2, 8, 1, 5]
count_result = len(my_list)
print("Number of elements in the list:", count_result)

sorted_result = sorted(my_list)
print("Sorted list:", sorted_result)

reversed_result = list(my_list)
print("Reversed list:", reversed_result)