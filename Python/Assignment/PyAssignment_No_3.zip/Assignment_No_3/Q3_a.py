my_tuple = (1, 2, 3, 4, 5)
for element in my_tuple:
    print(element)
print(type(my_tuple))