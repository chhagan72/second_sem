first_list = [1, 2, 3, 4, 5]
second_list = [6, 7, 8, 9, 10]
concatenated_list = second_list + first_list
print("Concatenated List:", concatenated_list)