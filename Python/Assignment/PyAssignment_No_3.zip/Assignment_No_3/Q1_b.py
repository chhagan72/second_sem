first_list = [1, 2, 3, 4, 5]
second_list = list(first_list)
print(second_list)