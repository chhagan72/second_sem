my_list = ["Apple", "Banana", "Cherry"]
repeat_count = int(input("Enter the number of times to repeat the list: "))
repeated_list = my_list*repeat_count
print(my_list)
print(repeated_list)