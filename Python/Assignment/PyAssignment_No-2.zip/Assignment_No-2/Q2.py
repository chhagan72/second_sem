score = int(input("Enter student score: "))
if score >=90:
    print("A")
elif score >= 70 and score < 90:
    print("B")
elif score >= 50 and score < 70:
    print("C")
elif score < 50:
    print("F")
