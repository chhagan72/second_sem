num1 = int(input("Enter a number: "))
if num1%2 == 0:
    print(num1," is Even number")
else:
    print(num1," is ODD number")