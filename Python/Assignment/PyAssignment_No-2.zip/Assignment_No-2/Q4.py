for i in range(7):
    if i == 3 or i == 6:
        continue
    print(i)
