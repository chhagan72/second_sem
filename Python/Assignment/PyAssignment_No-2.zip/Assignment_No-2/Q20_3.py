variable1 = input("Enter the value for variable 1: ")
variable2 = input("Enter the value for variable 2: ")
print("Before swapping:")
print("Variable 1:", variable1)
print("Variable 2:", variable2)
variable1, variable2 = variable2, variable1
print("\nAfter swapping:")
print("Variable 1:", variable1)
print("Variable 2:", variable2)
