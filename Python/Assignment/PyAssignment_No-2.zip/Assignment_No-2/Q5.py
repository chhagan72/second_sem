num = int(input("Enter a number "))
num2 = int(input("Enter a number "))
# num,num2 = (0,1)
while num <50:
    print(num2)
    num,num2 = num2,num + num2