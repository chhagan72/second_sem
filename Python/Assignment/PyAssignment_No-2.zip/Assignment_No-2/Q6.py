r = 3
c = 4
g =[]
for i in range(r):
    r1 = []
    for j in range(c):
        r1.append(i*j)
    g.append(r1)
    print(r1)