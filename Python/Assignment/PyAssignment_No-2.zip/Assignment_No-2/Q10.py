word = input("Enter a word: ")
reversed_word = word[::-1]
print("Reversed word:", reversed_word)
