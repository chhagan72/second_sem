num = int(input("Enter a number"))
check= int(input("Enter a check number"))
if num%check ==0:
    print(num," This number is evenly: ",check)
else:
    print("This number is not evenly ",num)
    