user_char = input("Enter a character: ")
ascii_value = ord(user_char)
print(f"The ASCII value of '{user_char}' is {ascii_value}.")
