import random
random_number = random.randint(1, 100)
print("Random Number:", random_number)